package model.domain;

public class moive2DTO {
	private String movenm;
	private String img;
	private String imgLink;
	private String genre;
	
	public moive2DTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public moive2DTO(String movenm, String img, String imgLink, String genre) {
		super();
		this.movenm = movenm;
		this.img = img;
		this.imgLink = imgLink;
		this.genre = genre;
	}
	
	
	
}
