package model;

public class movie2DAO {

}
